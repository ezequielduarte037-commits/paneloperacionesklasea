<?php
require_once __DIR__ . '/../auth_guard.php';
require_model('85');
$owner = $_SESSION['user'];
$modelo = '85';
require __DIR__ . '/panel_base.php';
