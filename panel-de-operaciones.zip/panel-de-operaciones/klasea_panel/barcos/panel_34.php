<?php
require_once __DIR__ . '/../auth_guard.php';
require_model('34');
$owner = $_SESSION['user'];
$modelo = '34';
require __DIR__ . '/panel_base.php';
